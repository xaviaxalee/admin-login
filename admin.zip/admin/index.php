<?php include('header.php');?>
       
<!-- <?php 
   
  //  if(!isset($_SESSION['admin_logged_in'])){
  //        header('location: login.php');
  //        exit();

   //} -->

?>
  		
<?php   $stmt2 = $conn->prepare("SELECT * FROM Bookings");
         $stmt2->execute();
         $bookings = $stmt2->get_result();
?>
          <!-- start: content -->
            <div id="content">
                

                <div class="col-md-12" style="padding:20px;">
                    <div class="col-md-12 padding-0">
                        <div class="col-md-8 padding-0">
                            <div class="col-md-12 padding-0">
                                <div class="col-md-6">
                                    <div class="panel box-v1">
                                      <div class="panel-heading bg-white border-none">
                                        <div class="col-md-6 col-sm-6 col-xs-6 text-left padding-0">
                                          <h4 class="text-left">Blog Subcribers</h4>
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6 text-right">
                                           <h4>
                                           <span class="icon-user icons icon text-right"></span>
                                           </h4>
                                        </div>
                                      </div>
                                      <div class="panel-body text-center">
                                      <?php 
                                            $sql = "SELECT COUNT(*) AS total_records FROM subscribers";
                                            $result = $conn->query($sql);
                                            
                                            if ($result->num_rows > 0) {
                                                // Fetch the result as an associative array
                                                $row = $result->fetch_assoc();
                                                
                                                // Access the total number of records
                                                $totalRecords = $row['total_records'];
                                        ?>
                                        <h1><?php echo $row['total_records']; ?></h1>
                                        <?php
                                        } else {
                                          echo "No records found";
                                      }
                                      ?>
                                        <a href="sunscribers.php">See all</a>
                                        <hr/>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="panel box-v1">
                                      <div class="panel-heading bg-white border-none">
                                        <div class="col-md-6 col-sm-6 col-xs-6 text-left padding-0">
                                          <h4 class="text-left">Booked Session</h4>
                                        </div>
                                        <div class="col-md-6 col-sm-6 col-xs-6 text-right">
                                           <h4>
                                           <span class="icon-basket-loaded icons icon text-right"></span>
                                           </h4>
                                        </div>
                                      </div>
                                      <div class="panel-body text-center">
                                        <?php 
                                            $sql = "SELECT COUNT(*) AS total_records FROM bookings";
                                            $result = $conn->query($sql);
                                            
                                            if ($result->num_rows > 0) {
                                                // Fetch the result as an associative array
                                                $row = $result->fetch_assoc();
                                                
                                                // Access the total number of records
                                                $totalRecords = $row['total_records'];
                                        ?>
                                        <h1><?php echo $row['total_records']; ?></h1>
                                        <?php
                                        } else {
                                          echo "No records found";
                                      }
                                      ?>
                                        <a href="Bookings.php">See all</a>
                                        <hr/>
                                      </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="panel box-v4">
                                      <div class="panel-body padding-0">
                                        <div class="col-md-12 col-xs-12 col-md-12 padding-0 box-v4-alert">
                                            <h2>Booked Session</h2>                                            
                                        </div>
                                        
                                                 <div class="responsive-table">
                                                 <table id="datatables-example" class="table table-striped table-bordered" width="100%" cellspacing="0">
                                                 <thead>
                                                   <tr>
                                                     <th>Name</th>
                                                     <th>Email</th>
                                                     <th>Phone</th>
                                                     <th>Class</th>
                                                     <th>Date</th>
                                                   </tr>
                                                 </thead>
                                                 <tbody>
                                                        <?php foreach($bookings as $row){?>
                                                    <tr>
                                                      <td><?php echo $row['full_name'];?></td>
                                                      <td><?php echo $row['email'];?></td>
                                                      <td><?php echo $row['phone'];?></td>
                                                      <td><?php echo $row['session_type'];?></td>
                                                      <td><?php echo $row['date'];?></td>

                                                    </tr>

                                                    <?php }?>

                                                  </tbody>
                                                </table>
                                                 </div>
                                             

                                    </div>
                                </div> 
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="col-md-12 padding-0">
                              <div class="panel box-v3">
                                <div class="panel-heading bg-white border-none">
                                  <h4>Recent Blogs post</h4>
                                </div>
                                <div class="panel-body">
                                  
                                  <?php include('../recent.php'); ?>

                              </div>
                            </div>

                        </div>
                    </div>


                
                </div>
      		  </div>
          <!-- end: content -->

          
      </div>

      <?php include('footer.php');?>